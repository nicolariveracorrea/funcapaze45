const http = require("http");
const fs = require("fs");
const path = require("path");

const port = Number(process.env.PORT) || 3000;
const rootDir = __dirname;
const clientsDir = path.join(rootDir, "clientes");
const clientsFile = path.join(clientsDir, "clientes.json");

fs.mkdirSync(clientsDir, { recursive: true });
if (!fs.existsSync(clientsFile)) {
  fs.writeFileSync(clientsFile, "[]\n", "utf8");
}

const readClients = () => JSON.parse(fs.readFileSync(clientsFile, "utf8"));
const writeClients = (clients) => fs.writeFileSync(clientsFile, `${JSON.stringify(clients, null, 2)}\n`, "utf8");

const sendJson = (response, statusCode, data) => {
  response.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(data));
};

const serveFile = (request, response) => {
  const requestedPath = request.url === "/" ? "/index.html" : request.url;
  const filePath = path.resolve(rootDir, `.${requestedPath}`);
  if (!filePath.startsWith(rootDir) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    response.writeHead(404);
    response.end("Not found");
    return;
  }

  const contentTypes = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json" };
  response.writeHead(200, { "Content-Type": contentTypes[path.extname(filePath)] || "application/octet-stream" });
  fs.createReadStream(filePath).pipe(response);
};

const server = http.createServer((request, response) => {
  if (request.method === "GET" && request.url === "/api/clients") {
    sendJson(response, 200, readClients());
    return;
  }

  if (request.method === "PUT" && request.url === "/api/clients") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    request.on("end", () => {
      try {
        const clients = JSON.parse(body);
        if (!Array.isArray(clients)) throw new Error("Invalid clients data");
        writeClients(clients);
        sendJson(response, 200, clients);
      } catch (error) {
        sendJson(response, 400, { error: error.message });
      }
    });
    return;
  }

  serveFile(request, response);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`funcapaze: http://localhost:${port}`);
});
